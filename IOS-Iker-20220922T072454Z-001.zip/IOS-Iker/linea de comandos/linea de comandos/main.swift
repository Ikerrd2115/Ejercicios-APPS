//
//  main.swift
//  linea de comandos
//
//  Created by Alumnos on 20/9/22.
//

import Foundation

print("Holaaaa")


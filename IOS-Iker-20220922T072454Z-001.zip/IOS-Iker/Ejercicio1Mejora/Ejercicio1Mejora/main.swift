//
//  main.swift
//  Ejercicio1Mejora
//
//  Created by Alumnos on 21/9/22.
//

import Foundation

var notas: Int?

print("cuantos examenes ha tenido?")
let notasTexto = readLine()
notas =  Int(notasTexto ?? 5)

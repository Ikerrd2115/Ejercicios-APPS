/*
 * Conceptos básico de programación en Swift
 */

import Foundation

let numeroVidasMax = 10
var numeroVidas = numeroVidasMax

print(numeroVidas)
numeroVidas -= 1 // numeroVidas = numeroVidas - 1
var texto: String = "hola"

let letraA: Character = "a"

print(texto + " te quedan " + String(numeroVidas) + " vidas") // Contatenación
print(texto, "te quedan", numeroVidas, "vidas")


var vidasUsuarioEntero: Int?

repeat {
    print("¿Cuantas vida quieres que te añada?")
    let vidasUsuarioTexto = readLine()
    vidasUsuarioEntero = Int(vidasUsuarioTexto!) // Casting de String a Int
    print(vidasUsuarioTexto)
    if vidasUsuarioEntero == nil {
        print("Tiene que ser un número entero")
    }
} while vidasUsuarioEntero == nil

numeroVidas = numeroVidas + (vidasUsuarioEntero ?? 0)

print(texto, "te quedan", numeroVidas, "vidas")


let numeroOpcional: Float? = nil // Como Integer en Java
let numero: Float = 4.3 // como int en Java

if numeroOpcional != nil {
    let resultado = numeroOpcional! * 2
}

var nombre: String? = nil
var edad: Int? = nil

if nombre == nil {
    print("No has indicado tu nombre")
}

switch vidasUsuarioEntero! {
case 1:
    print("Caso 1")
case 2, 5:
    print("Caso 2")
case 4...23:
    print("Caso 3")
default:
    print("Caso por defecto")
}

for i in 1...10 {
    print(i)
}

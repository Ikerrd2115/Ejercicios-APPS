//
//  main.swift
//  Ejercicio1
//
//  Created by Alumnos on 21/9/22.
//

import Foundation

	
var nota1: Int?
var nota2: Int?
var nota3: Int?
var nota4: Int?
var nota5: Int?
var media: Int = 0

repeat {
    print("deme las notas de sus 5 examenes")
    let nota1Texto = readLine()
    nota1 = Int(nota1Texto!) // Casting de String a Int
    
    let nota2Texto = readLine()
    nota2 = Int(nota2Texto!) // Casting de String a Int
    
    let nota3Texto = readLine()
    nota3 = Int(nota3Texto!) // Casting de String a Int
    
    let nota4Texto = readLine()
    nota4 = Int(nota4Texto!) // Casting de String a Int
    
    let nota5Texto = readLine()
    nota5 = Int(nota5Texto!) // Casting de String a Int
    
    if nota1 == nil || nota2 == nil || nota3 == nil || nota4 == nil || nota5 == nil{
        print("Tiene que ser un número entero")
    }
} while nota1 == nil || nota2 == nil || nota3 == nil || nota4 == nil || nota5 == nil

media = (nota1! + nota2! + nota3! + nota4! + nota5!) / 5

print("tu media es", media )
